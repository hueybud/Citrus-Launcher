var path = require('path');
var os = require('os')
var fs = require('fs');
const { createHash } = require('crypto');
const unzipper = require('unzipper');
const etl = require('etl');
var filePath = path.join(os.homedir(), 'Desktop', 'gcm folder', 'G4QE01.gcm')
var api = require('./api')
var ini = require('ini')


//const ffmpeg = require('ffmpeg-static')
//const { exec } = require('child_process');
//var ourArgument = ffmpeg + " -y -rtbufsize 100M -f gdigrab -t 00:00:30 -framerate 60 -probesize 10M -draw_mouse 1 -i title=Dolphin -c:v libx264 -r 30 -preset ultrafast -tune zerolatency -crf 25 -pix_fmt yuv420p c:/video_comapre2.mp4"
//console.log(ourArgument)
/*
exec(ourArgument, [], (error, stdout, stderr) => {
    console.log(stdout);
  })
*/
/*
setTimeout(function(){
    const { spawn } = require("child_process");
    const process = spawn(
        ffmpeg,
      ["-probesize", "10M", "-f", "gdigrab", "-framerate", "60", "-i", "title=Dolphin", "-b:v", "5M", "-f", "flv", "-"],
      { stdio: "pipe" }
    );
    const stream = process.stdout;
    const { createWriteStream } = require("fs");
    
    const file = createWriteStream("capture.flv");
    stream.pipe(file);
}, 2000)
*/